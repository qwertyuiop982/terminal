/* Binary mode I/O.
   Copyright 2017-2026 Free Software Foundation, Inc.

   This file is free software: you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as
   published by the Free Software Foundation; either version 2.1 of the
   License, or (at your option) any later version.

   This file is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

#define BINARY_IO_INLINE _GL_EXTERN_INLINE
#include <config.h>
#include "binary-io.h"

#if defined __DJGPP__ || defined __EMX__
# include <unistd.h>

int
set_binary_mode (int fd, int mode)
{
  if (isatty (fd))
    /* If FD refers to a console (not a pipe, not a regular file),
       O_TEXT is the only reasonable mode, both on input and on output.
       Silently ignore the request.  If we were to return -1 here,
       all programs that use xset_binary_mode would fail when run
       with console input or console output.  */
    return O_TEXT;
  else
    return _gl_set_fd_mode (fd, mode);
}

#endif
